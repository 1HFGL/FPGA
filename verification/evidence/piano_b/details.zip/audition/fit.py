"""只生成隔离候选。48槽/原频率/相位/噪声标志/原吉他与位宽保持。"""
from pathlib import Path
import json, math, hashlib
import numpy as np
ROOT=Path(__file__).resolve().parents[2]; OUT=Path(__file__).resolve().parent
FS=48000
oldfit=json.loads((ROOT/'model/piano_reference_fit.json').read_text())
words=[int(s,16) for s in (ROOT/'rtl/rom/piano_v3_modes.mem').read_text().split()]
def unpack(w): return [(w>>42)&0xffffffff,(w>>26)&65535,(w>>10)&65535,w&1023,(w>>74)&1]
def pack(m):
    inc,amp,loss,phase,noise=map(int,m)
    return (noise<<74)|(inc<<42)|(amp<<26)|(loss<<10)|phase
def measure(x,fs,times,onset,centers):
    rows=[]
    for t in times:
        start=round((onset+t)*fs); chunk=x[start:start+round(.09*fs)]
        nfft=65536; spec=np.abs(np.fft.rfft(chunk*np.hanning(len(chunk)),nfft))**2
        hz=np.fft.rfftfreq(nfft,1/fs)
        row=[]
        for h,c in enumerate(centers):
            # 邻近泛音中点限制积分窗口，避免把同一频带重复计入两个泛音。
            lo=max(c-20,(centers[h-1]+c)/2 if h else 0)
            hi=min(c+20,(centers[h+1]+c)/2 if h+1<len(centers) else 20000,20000)
            row.append(float(np.sqrt(spec[(hz>=lo)&(hz<=hi)].sum())) if hi>lo else 0.)
        rows.append(row)
    return np.array(rows)
times=np.array([.015,.04,.08,.16,.30,.50,.80,1.2,1.8,2.5])
profiles=[]
for f in oldfit:
    note=f['note']; x=np.load(OUT/'reference'/f'C{note//12-1}.npy')
    # 在谱峰估计的刚性系数附近找峰，不直接采用旧表中高频重复中心。
    fundamental=f['measured_f0']; h=np.arange(1,25)
    predicted=fundamental*h*np.sqrt((1+f['stiffness']*h*h)/(1+f['stiffness']))
    chunk=x[round((f['onset_seconds']+.08)*44100):round((f['onset_seconds']+.6)*44100)]
    hz=np.fft.rfftfreq(262144,1/44100); spec=np.abs(np.fft.rfft(chunk*np.hanning(len(chunk)),262144))
    centers=[]
    for c in predicted:
        ix=np.flatnonzero((hz>c-fundamental*.23)&(hz<c+fundamental*.23)&(hz<20000))
        centers.append(float(hz[ix[np.argmax(spec[ix])]]) if len(ix) else float(c))
    centers=np.maximum.accumulate(centers)
    measured=measure(x,44100,times,f['onset_seconds'],centers)
    measured/=max(measured.max(),1e-9)
    amplitudes=[]; taus=[]; dual=[]
    for i in range(24):
        y=measured[:,i]
        valid=(times>=.04)&(times<=1.8)&(y>max(y.max()*.06,.0003))
        if valid.sum()<3 or y.max()<.001:
            amplitudes.append(0.);taus.append(.25);dual.append([0.,.25,0.,1.]);continue
        slope,intercept=np.polyfit(times[valid]+.045,np.log(y[valid]),1)
        tau=float(np.clip(-1/min(slope,-.18),.07,4.5))
        amp=float(np.clip(np.exp(intercept),0,2.5))
        amplitudes.append(amp);taus.append(tau)
        # 双指数非负最小二乘：首分量快速衰减，第二分量承担后段。
        best=(float('inf'),None)
        t=times+.045; weight=1/np.maximum(y,y.max()*.12)
        for tf in np.geomspace(.035,min(1.2,tau*1.1),18):
            for ts in np.geomspace(max(tf*1.5,.3),5.5,18):
                basis=np.array([np.exp(-t/tf),np.exp(-t/ts)]).T
                bw=basis*weight[:,None]; yw=y*weight
                coeff=np.linalg.lstsq(bw,yw,rcond=None)[0]
                if np.any(coeff<0):
                    candidates=[]
                    for j in range(2):
                        a=max(0,float(np.dot(bw[:,j],yw)/max(np.dot(bw[:,j],bw[:,j]),1e-12)))
                        v=np.zeros(2);v[j]=a;candidates.append(v)
                    coeff=min(candidates,key=lambda v:np.sum((bw@v-yw)**2))
                error=float(np.mean((bw@coeff-yw)**2))
                if error<best[0]:best=(error,[float(coeff[0]),float(tf),float(coeff[1]),float(ts)])
        dual.append(best[1])
    profiles.append(dict(note=note,centers=centers.tolist(),times=times.tolist(),measured=measured.tolist(),
                         amplitudes=amplitudes,taus=taus,dual=dual,onset=f['onset_seconds']))
    print('Reference fit',note,'active partials',sum(v>0 for v in amplitudes),flush=True)
(OUT/'fit.json').write_text(json.dumps(profiles,indent=2))
def interpolate(note,key):
    i=min(2,(note-48)//12); t=(note-profiles[i]['note'])/12
    a=np.array(profiles[i][key]); b=np.array(profiles[i+1][key])
    return np.exp((1-t)*np.log(np.maximum(a,1e-8))+t*np.log(np.maximum(b,1e-8)))
def loss(tau):return min(65535,max(1,round((1-math.exp(-1/(FS*tau)))*2**24)))
variants={'baseline':words.copy()}
for label in ('candidate_a','candidate_b'):
    result=words.copy()
    for note in range(48,85):
        start=8192+note*64; modes=[unpack(w) for w in words[start:start+48]]
        aa=interpolate(note,'amplitudes'); tt=interpolate(note,'taus'); dd=interpolate(note,'dual')
        values=[]
        for k,m in enumerate(modes):
            if k<24: h=k; group=0
            elif k<36: h=k-24; group=1
            elif k<46: h=k-36; group=2
            elif k==46: h=0;group=3
            else: values.append((.006,.0045));continue
            divisor=1+(.48 if h<12 else 0)+(.34 if h<10 else 0)
            if label=='candidate_a' or h>=12:
                a=aa[h]*[1,.48,.34,.055][group]/divisor
                tau=tt[h]*[1,1,1,1.65][group]
            else:
                fast,tf,slow,ts=dd[h]
                if group==0:a,tau=fast+slow*.2,tf
                elif group in (1,2):
                    share=(.48 if group==1 else .34)/(.82 if h<10 else .48)
                    a,tau=slow*.8*share,ts
                else:a,tau=(fast+slow)*.035,min(5.5,ts*1.15)
            values.append((a,max(.035,min(6.,tau))))
        # 保留原单音总幅度预算，防止“更响就是更好”的偏差及16位溢出。
        values=[(0. if modes[k][0]==0 and not modes[k][4] else a,t) for k,(a,t) in enumerate(values)]
        budget=sum(m[1] for m in modes)
        scale=min(budget/max(sum(a for a,t in values),1e-9),8190/max(max(a for a,t in values),1e-9))
        amps=np.array([round(a*scale) for a,t in values],dtype=int)
        if amps.sum()>budget: amps[amps.argmax()]-=int(amps.sum()-budget)
        assert amps.max()<8192 and amps.sum()<=15048
        for k,m in enumerate(modes):
            m[1]=int(amps[k]);m[2]=loss(values[k][1]);result[start+k]=pack(m)
        # 直接拟合的弱长尾会被ceil(Q0.24乘法)的最小减量过早耗尽。
        # 在当前定点格式内收敛到保守改动；不增加幅度位宽或改变运算。
        oldm=[unpack(w) for w in words[start:start+48]]
        newm=[unpack(w) for w in result[start:start+48]]
        for k,(old,new) in enumerate(zip(oldm,newm)):
            if label=='candidate_a':
                new[1]=round(old[1]*.75+new[1]*.25)
                new[2]=round(old[2]*.85+new[2]*.15)
                if k>=24:new[2]=min(old[2],new[2])
                if k==46:new[1:3]=old[1:3]
            else:
                new[1]=round(old[1]*.65+new[1]*.35)
                if k<24:new[2]=round(old[2]*.75+min(new[2],old[2]*2)*.25)
                elif k<46:
                    new[1]=old[1]
                    new[2]=max(1,round(old[2]*(.65 if k<36 else .5)))
                elif k==46:new[1]=old[1];new[2]=max(1,round(old[2]*.5))
                else:new[1:3]=old[1:3]
        ratio=min(1.,budget/max(sum(m[1] for m in newm),1))
        for k,m in enumerate(newm):
            m[1]=int(m[1]*ratio);assert m[1]<8192
            result[start+k]=pack(m)
    variants[label]=result
    assert result[:8192]==words[:8192], 'Guitar changed'
    for n in range(128):
        for k in range(64):
            old=words[8192+n*64+k];new=result[8192+n*64+k]
            if not(48<=n<=84 and k<48):assert old==new
            assert (old&1023)==(new&1023) and (old>>42)==(new>>42), 'Frequency/phase/noise changed'
for label,data in variants.items():
    path=OUT/label;path.mkdir(exist_ok=True)
    (path/'piano_v3_modes.mem').write_text(''.join(f'{w:019x}\n' for w in data),encoding='ascii')
    table=np.array([[unpack(data[8192+n*64+k]) for k in range(48)] for n in range(128)],dtype='<u4')
    table.tofile(path/'piano_coefficients.bin')
    print(label,'table',hashlib.sha256((path/'piano_v3_modes.mem').read_bytes()).hexdigest(),flush=True)
# 固定比较曲目：4个参考音、音阶、和弦与短旋律。所有版本事件完全相同。
events=[]
for note in (48,60,72,84):events.append((f'anchor_{note}',note,144000,163200,0))
for note in (48,52,55,60,62,64,65,67,69,71,72,76,79,84):
    events.append((f'short_{note}',note,16800,24000,0))
for note in (48,52,55,60,64,67,53,57,62,65,59):
    events.append((f'chord_{note}',note,57600,67200,0))
# 验证用含短释放的独立单音，后续与当前RTL逐样本对照。
for i,n in enumerate((48,60,72,84)):events.append((f'check_{n}',n,96,256,i))
(OUT/'jobs.csv').write_text('\n'.join(','.join(map(str,e)) for e in events)+'\n',encoding='ascii')
