# 钢琴参数试听实验（2026-10-26）

这是隔离试听，不是新版固件；没有替换正式 RTL/ROM，没有综合、布局布线或烧录。
入口 `index.html`。音频位于 `audio/`，可直接播放 WAV。

## 试听方法

- `compare_C4_reference_original_A_B.wav`：真实钢琴 → 原版 → 候选 A → 候选 B，每段 3.4 秒，间隔 0.5 秒。
- `registers_reference_original_A_B.wav`：C3、C4、C5、C6，每个音均按以上四段顺序。
- `baseline_performance.wav`、`candidate_a_performance.wav`、`candidate_b_performance.wav`：完全相同的音区探测、旋律和四组和弦。
- 所有合成音频均为干声整数模型，未加入明亮度滤波、合唱、延迟、混响或模拟 DAC。其目的为隔离音色参数差异，不代表整机录音。
- 单音四段比较按各段同一 30～1000ms 窗口匹配 RMS，每段仅用一个常数播放增益；每版整段旋律也仅用一个常数增益。没有 EQ、压缩或动态归一化。单音剪辑末端 10ms 淡出仅消除截取点击。

## 实际变化

候选仅修改 MIDI48～84 钢琴的分量初始幅度、Q0.24 衰减系数。32声部、每音48槽、频率、相位、噪声标志、吉他系数、现有包络和正式调度结构保持。

A：真实录音拟合结果以较小比例混入原幅度与衰减，保留已有慢衰减分量。
B：在同样48槽中调整快慢分量，保留足够幅度的慢尾音，避免定点最小减量过早耗尽尾音。

第一次直接拟合因弱分量在当前定点格式中提前归零而拒绝；其结果记录于 `rejected_direct_fit.json`。不增加位宽、不更改 RTL 来迎合拟合。

## 验证与结论边界

最终三套表各通过 4800 帧、153600 个声部输出的整数模型与未修改 RTL 对照；三套合计 460800 个声部样本。覆盖32槽、C3起的32个音、起音、释放完成和静音。32声部核心保持 R925。翻转一位期望值的负向检查被拒绝。

正式 R958 链路通过源码未改来保持；本次没有重新跑候选的完整效果器/DAC长回归、布局布线或实物试听。仿真使用透明双读口系数模型；打包的数值/字段范围在生成时检查，未重新执行厂商 ROM 原语资格测试。

开发诊断平均对数泛音包络误差：原版26.78dB，A27.80dB，B25.27dB。B的C3/C5改善，C4/C6退步；A未显示该指标改善。该指标不是听感分数。四个参考音参与拟合，时间窗口虽未用于最初拟合，但已用于修改候选，因此不是独立测试集。不宣称音色已全面改善或接近真实钢琴已验收。

请优先比较敲击感、尾音自然度、各音区一致性、和弦清晰度。试听确认后才能决定是否采用某一候选或继续只调参数。

## 来源与复现

参考：[University of Iowa Electronic Music Studios](https://theremin.music.uiowa.edu/MISpiano.html)。使用项目既有 Piano.mf.C3/C4/C5/C6.aiff，原文件 SHA256 与 `model/piano_reference_sources.json` 一致；原录音只作分析与参考试听，不作为 FPGA PCM 波表。

按顺序运行（Python需numpy，PowerShell支持Add-Type，ModelSim路径见脚本）：

```text
python prepare.py
python fit.py
python prepare_rtl_check.py
powershell -File render.ps1
python check_rtl.py
python finish.py
```

脚本按自身路径定位仓库。`summary.json` 包含增益、每音指标、试听哈希和输入哈希；`rtl_checks.json` 包含逐候选仿真输入身份。`formal_before.json` 是原文件哈希清单，不是代码备份。没有建立或遗留正式工程备份副本。
