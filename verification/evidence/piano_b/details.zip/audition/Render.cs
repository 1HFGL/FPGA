// 离线逐样本整数模型；不改变FPGA工程。受测条件：全新钢琴音，力度127，中心弯音。
using System;
using System.IO;
public static class PianoAudition {
 public static void Run(string root,string sineFile) {
  string[] sineLines=File.ReadAllLines(sineFile);int[] sine=new int[1024];
  for(int i=0;i<1024;i++)sine[i]=unchecked((short)Convert.ToUInt16(sineLines[i],16));
  foreach(string variant in new string[]{"baseline","candidate_a","candidate_b"}) {
   string dir=Path.Combine(root,variant);uint[,,] coeff=new uint[128,48,5];
   using(var r=new BinaryReader(File.OpenRead(Path.Combine(dir,"piano_coefficients.bin"))))
    for(int n=0;n<128;n++)for(int m=0;m<48;m++)for(int k=0;k<5;k++)coeff[n,m,k]=r.ReadUInt32();
   foreach(string line in File.ReadAllLines(Path.Combine(root,"jobs.csv"))) {
    string[] s=line.Split(',');int note=int.Parse(s[1]),hold=int.Parse(s[2]),length=int.Parse(s[3]),index=int.Parse(s[4]);
    uint[] phase=new uint[48];long[] amp=new long[48];
    for(int m=0;m<48;m++){phase[m]=coeff[note,m,3]<<22;amp[m]=(long)coeff[note,m,1]<<8;}
    uint lfsr=(uint)(0x1ace ^ ((index*0x1234)&65535)),bend=0;
    int correction=0,fade=0;
    using(var w=new BinaryWriter(File.Create(Path.Combine(dir,s[0]+".pcm"))))
    for(int t=0;t<length;t++) {
     int env=t<hold?Math.Min(65536,(t+1)*1024):Math.Max(0,65536-(t-hold+1)*16);
     // R1使用旧LFSR，弯音则在首次模态读之前更新。
     int noise=unchecked((short)lfsr);
     lfsr=((lfsr<<1)|(((lfsr>>15)^(lfsr>>13)^(lfsr>>12)^(lfsr>>10))&1))&65535;
     if(t>0 && bend>0)bend=bend-(bend>>9)-1;
     long sum=0;
     for(int m=0;m<48;m++) {
      if(env==0)amp[m]=0;
      int source=coeff[note,m,4]!=0?noise:sine[phase[m]>>22];
      if(coeff[note,m,1]!=0)sum+=((long)source*(amp[m]>>8))>>15;
      phase[m]=unchecked(phase[m]+(uint)(((ulong)coeff[note,m,0]*(65536+bend))>>16));
      long decrease=(amp[m]*coeff[note,m,2]+0xffffff)>>24;
      amp[m]=(amp[m]<256 || amp[m]<=decrease)?0:amp[m]-decrease;
     }
     int raw=unchecked((short)((sum*env)>>16));
     int value=env==0?0:(t==0?0:Math.Max(-32768,Math.Min(32767,raw+((correction*fade)>>6))));
     if(t==0){correction=-raw;fade=63;}else if(fade>0)fade--;
     w.Write((short)value);
    }
   }
   Console.WriteLine("Rendered integer modal samples: "+variant);
  }
 }
}
